print("Exercício 4: Soma dos ímpares múltiplos de 3 de 1 até 500")
soma_impares_multiplos_3 = sum(x for x in range(1, 501) if x % 2 == 1 and x % 3 == 0)
print(f"Soma dos ímpares múltiplos de 3 = {soma_impares_multiplos_3}")
