print("Exercício 5: Tabuada do 5")
for i in range(1, 11):
    print(f"{i} x 5 = {i * 5}")
