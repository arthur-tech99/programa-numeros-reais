print("Exercício 1: Conversão de 45°F a 80°F")
print("Fahrenheit | Celsius")
for f in range(45, 81):
    c = 5 * (f - 32) / 9
    print(f"{f:.1f} ºF | {c:.3f} ºC")
