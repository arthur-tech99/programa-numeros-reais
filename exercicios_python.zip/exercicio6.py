print("Exercício 6: Tabuada de um número fornecido pelo usuário")
numero = int(input("Digite o número para ver a tabuada: "))
for i in range(1, 11):
    print(f"{i} x {numero} = {i * numero}")
