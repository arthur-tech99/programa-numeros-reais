print("Exercício 3: Soma de 1 até 500")
soma = sum(range(1, 501))
print(f"Soma de 1 até 500 = {soma}")
